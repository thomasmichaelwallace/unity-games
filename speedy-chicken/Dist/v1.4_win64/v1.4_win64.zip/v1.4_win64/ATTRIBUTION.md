<ul>
  <li>
    <a href="https://soundcloud.com/athenswill2/8bit" target="_blank">"8bit"</a> by <a href="https://soundcloud.com/athenswill2" target="_blank">athenswill2</a> is licensed under <a href="http://creativecommons.org/licenses/by-sa/2.0" target="_blank">CC BY-SA 2.0</a>
  </li>
  <li>
    <a href="https://freesound.org/people/MatthewWong/sounds/361564/" target="_blank">"Ding Dong"</a> by <a href="https://freesound.org/people/MatthewWong/" target="_blank">MatthewWong</a> is in the <a href="https://wiki.creativecommons.org/Public_domain" target="_blank">Public Domain, CC0</a>
  </li>
  <li>
    <a href="https://freesound.org/people/MarlonHJ/sounds/242740/" target="_blank">"Engine » ENGINE.WAV"</a> by <a href="https://freesound.org/people/MarlonHJ/" target="_blank">MarlonHJ</a> is in the <a href="https://wiki.creativecommons.org/Public_domain" target="_blank">Public Domain, CC0</a>
  </li>
</ul>
